
import './App.css';

import RoutePage from './routers/RoutePage';



function App() {
  return (
    <div className="App">
     <RoutePage/>
     
    </div>
  );
}

export default App;
